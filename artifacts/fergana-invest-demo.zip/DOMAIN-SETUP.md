# fargona-invest.uz domenini ulash

Tanlangan domen: **fargona-invest.uz**. 2026-10-11 tekshiruvda ochiq DNS A va NS so‘rovlari NXDOMAIN qaytardi. Bu domen sotib olish uchun bo‘sh ekanini yoki egaligini tasdiqlamaydi. Registrar orqali ro‘yxatdan o‘tkazish holati tekshiriladi.

Domen buyurtmachiga tegishli qilib ro‘yxatdan o‘tkazilgach, DNS panelida quyidagilar kiritiladi:

| Turi | Nomi | Qiymati |
|---|---|---|
| A | @ | 185.199.108.153 |
| A | @ | 185.199.109.153 |
| A | @ | 185.199.110.153 |
| A | @ | 185.199.111.153 |
| CNAME | www | nursultonsohibjonovrustamov-wq.github.io |

TTL: registrar standarti. Domenning email MX/TXT yozuvlari saqlanadi. Registrarga qarab @ o‘rniga fargona-invest.uz kiritilishi mumkin.

GitHub Pages sozlamasi: repository Settings → Pages → Custom domain: fargona-invest.uz. DNS tekshiruvi va sertifikat chiqarilgach Enforce HTTPS yoqiladi. Domen egaligi GitHub hisobining Pages sozlamalarida tekshiriladi; platforma bergan TXT qiymati ishlatiladi, taxmin qilinmaydi.

Rasmiy qo‘llanma: https://docs.github.com/en/pages/configuring-a-custom-domain-for-your-github-pages-site/managing-a-custom-domain-for-your-github-pages-site

Hozirgi ishlayotgan demo manzili saqlangan. Ro‘yxatdan o‘tmagan yoki egaligi tasdiqlanmagan domen joriy Pages sozlamasiga qo‘yilmadi. Domen sotib olinmagan, DNS va GitHub custom-domain sozlamalari hali qo‘llanmagan.
